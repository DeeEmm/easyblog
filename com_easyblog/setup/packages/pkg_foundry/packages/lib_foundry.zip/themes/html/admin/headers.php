<?php
/**
* @package		Foundry
* @copyright	Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Foundry is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');
?>
<div class="app-head">
	<h2 class="text-lg leading-md text-gray-800"><?php echo JText::_($title); ?></h2>
	<?php if ($description !== false) { ?>
		<p><?php echo JText::_($description); ?></p>
	<?php } ?>
</div>
